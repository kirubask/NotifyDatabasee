package com.example.notifydatabase;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class FragmentOne extends Fragment {

    View view;
    EditText email;
    EditText phone;
    Button submit;
    private  DataBaseHelper dataBaseHelper;

    public  void Fragment(DataBaseHelper dataBaseHelper) {
        this.dataBaseHelper = dataBaseHelper;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_one, container, false);

        return view;

    }
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        email = view.findViewById(R.id.emailEditText);
        phone = view. findViewById(R.id.phoneNumberEditText);
        submit = view.findViewById(R.id.submitBtn);
        DataBaseHelper dataBaseHelper = new DataBaseHelper(requireContext());

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                addUsers();
            }
        });
    }

    private void addUsers() {
        String name = email.getText().toString().trim();
        String phoneNumber = phone.getText().toString().trim();
        if (TextUtils.isEmpty(name) && TextUtils.isEmpty(phoneNumber)){
            Toast.makeText(getContext(), "Please enter the name and phone-number !", Toast.LENGTH_SHORT).show();
        }
        else if (dataBaseHelper != null && dataBaseHelper.addUser(name,phoneNumber) ){
            Toast.makeText(getContext(), "Data Added as" + name + phoneNumber, Toast.LENGTH_SHORT).show();
        }
        else{
            Toast.makeText(getContext(), "Data was not added", Toast.LENGTH_SHORT).show();
        }
    }


}